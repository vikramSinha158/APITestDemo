﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITest.TestData
{
    internal class EmployeeObject
    {
        public int InitialBalance { get; set; }
        public string? AccountName { get; set; }
        public string? Address { get; set; }
    }
}
